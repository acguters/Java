// hello2.java
// my haiku

import static java.lang.System.*;

class hello2 {

	public static void main( String[] args){
		System.out.println("Computer Science");
		System.out.println("Please don't be too hard on me");
		System.out.println("Or else I will cry");
}
}
